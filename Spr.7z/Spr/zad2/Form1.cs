namespace zad2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int[] tab;

        private void button2_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            tab =new int[dataGridView1.ColumnCount];
            for (int i =0; i<dataGridView1.Columns.Count;i++)
            {
                tab[i] = random.Next(10, 100);
                dataGridView1.Rows[0].Cells[i].Value = tab[i];
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView2.Visible = true;
            for (int i=0;i<10;i++)
            {
                int liczba =tab[i];
                int odwrocona =(liczba%10)*10+(liczba /10);
                dataGridView2.Rows[0].Cells[i].Value = odwrocona;
            }
        }
    }
}
