namespace zad3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int[,] tab=new int[7, 5];
        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.ColumnCount = 5;
            dataGridView1.RowCount = 7;
            dataGridView2.ColumnCount = 1;
            dataGridView2.RowCount = 7;
            Random random = new Random();
            for (int i=0; i<7;i++)
            {
                for (int j=0;j<5;j++)
                {
                    int liczba=random.Next(100, 1000);
                    dataGridView1.Rows[i].Cells[j].Value = liczba;
                    tab[i, j]=liczba;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView2.Visible = true;
            for (int i=0;i<7;i++)
            {
                int max =tab[i,0];
                for (int j=1; j<5;j++)
                {
                    if (tab[i,j] > max)
                        max =tab[i,j];
                }
                dataGridView2.Rows[i].Cells[0].Value = max;
            }
        }
    }
}
